"""New R4 pure bound-neutral wire plus typed/window diagnostics; no refit."""
from context_v2 import neutral_v2,InputRejected
from reference_v3 import TrustedCallV3,validate_ingress_v3,resolve_reference_v3
from detector_r4 import detect_candidates_r4
from window_r4 import score_date_r4
from guard_v3 import wire_errors_v3

def predict_r4(snapshot,trusted,registry,state,schema,source_admission=None,date_bundle=None):
    if not isinstance(trusted,TrustedCallV3): raise InputRejected("Independent source binding required")
    try:
        reason=validate_ingress_v3(snapshot,trusted)
        wire=neutral_v2(trusted.binding_context,reason or "untrained_head")
        if reason: return wire,{"ingress_reason":reason,"qualified":False}
        detector=detect_candidates_r4(snapshot["utterance"]["text"],snapshot["question"]["role"],snapshot["targets"])
        scores=[score_date_r4(snapshot,c,source_admission,date_bundle) for c in detector["candidates"] if c["kind"]=="date"]
        label={"readback":"readback_affirmation","offer":"offer_acceptance"}.get(snapshot["question"]["role"],"unknown")
        reference=resolve_reference_v3(snapshot,label,trusted,registry,state,bool(detector["candidates"] or detector.get("nondate_candidates")))
        errors=wire_errors_v3(wire,snapshot,schema)
        return wire,{"detector":detector,"date_scores":scores,"reference":reference,"wire_errors":errors,
                     "all_abstain":True,"qualified":False,"normalization":"not_implemented",
                     "primary_act_target_polarity_untrained":True}
    except (KeyError,TypeError,ValueError,AttributeError,IndexError,OverflowError):
        return neutral_v2(trusted.binding_context,"runtime_failure"),{"qualified":False,"runtime_failure":True}
